# Clip-Path Revealing Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/suez/pen/grJONP](https://codepen.io/suez/pen/grJONP).

Source of inspiration - https://dribbble.com/shots/2705517-boldybae