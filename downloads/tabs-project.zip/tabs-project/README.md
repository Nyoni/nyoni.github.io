# Tabs project

A Pen created on CodePen.io. Original URL: [https://codepen.io/JustAlbertCode/pen/dyddoeV](https://codepen.io/JustAlbertCode/pen/dyddoeV).

