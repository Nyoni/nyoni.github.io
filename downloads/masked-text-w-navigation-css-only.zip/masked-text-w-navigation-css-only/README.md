# Masked Text w/ Navigation (CSS Only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/tingc10/pen/ERZbXg](https://codepen.io/tingc10/pen/ERZbXg).

@keyframers Oceanic Overlays exercise