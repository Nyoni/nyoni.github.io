# Slider using property Clip v.2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/aspeddro/pen/KzGEQL](https://codepen.io/aspeddro/pen/KzGEQL).

https://developer.mozilla.org/pt-BR/docs/Web/CSS/clip