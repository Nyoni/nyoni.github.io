# Tabs Widget. No JS!

A Pen created on CodePen.io. Original URL: [https://codepen.io/dmitrysharabin/pen/qBBNjZP](https://codepen.io/dmitrysharabin/pen/qBBNjZP).

