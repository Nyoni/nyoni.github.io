# Custom Tabs Selector

A Pen created on CodePen.io. Original URL: [https://codepen.io/ham47mani/pen/MWVKVJW](https://codepen.io/ham47mani/pen/MWVKVJW).

Custom Tabs Selector
Pug, Sass, Javascript