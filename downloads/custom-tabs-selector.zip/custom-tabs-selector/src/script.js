//==================== Start Custom Tabs Selector ===================
const tabsContainer = document.querySelector("section .tabs"),
      tabs = tabsContainer.querySelectorAll("li"),
      selector = tabsContainer.querySelector(".selector");

//- animationSelector function to move background
function animationSelector () {
  let activeItem = tabsContainer.querySelector("li.active");
  selector.style.width = activeItem.offsetWidth + "px";
  selector.style.left = activeItem.offsetLeft + "px";
}

//- Add Events to tabs items
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabsContainer.querySelector("li.active").classList.remove("active");
    tab.classList.add("active");
    animationSelector();
  });
});

//- Call animationSelector function
animationSelector();
//==================== End Custom Tabs Selector ===================
