# Slider transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/fluxus/pen/rweVgp](https://codepen.io/fluxus/pen/rweVgp).

Exploring some slider transitions. I am using Swiper slider with parallax option enabled. Playing with CSS filters mostly here.