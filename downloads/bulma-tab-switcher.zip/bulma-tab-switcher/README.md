# bulma-tab-switcher

A Pen created on CodePen.io. Original URL: [https://codepen.io/brightrain/pen/OJQqMgX](https://codepen.io/brightrain/pen/OJQqMgX).

An example of tab switching using the bulma css framework