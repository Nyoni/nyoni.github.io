# Parallax Flipping Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolaspavlotsky/pen/wqGgLO](https://codepen.io/nicolaspavlotsky/pen/wqGgLO).

