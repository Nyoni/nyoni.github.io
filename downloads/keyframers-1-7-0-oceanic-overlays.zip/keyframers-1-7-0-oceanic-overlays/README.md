# @keyframers 1.7.0 | Oceanic Overlays

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/RyzaYY](https://codepen.io/shshaw/pen/RyzaYY).

Watch @davidkpiano and @shshaw code this live! https://youtu.be/kd_zuEYCDck 

This week, David Khourshid and Stephen Shaw save the oceans using only CSS! Follow along as they toggle, slide and clip to create an inspiring page design. Streamed live on May 24, 2018. 

Shownotes: 

* Animation Inspiration: 
https://dribbble.com/shots/4592180-Save-The-Oceans-Website
* Final code: https://codepen.io/shshaw/pen/RyzaYY/

Additional Resources:

* CSS Mask animation https://codepen.io/shshaw/pen/NMeXoN
* Encroachment (CSS-only) https://codepen.io/shshaw/pen/OZGMKq/
* Overriding Default Button Styles https://css-tricks.com/overriding-default-button-styles/
* CSS-only Colorful Calendar Concept https://codepen.io/davidkpiano/pen/xwyVXO

Like what we're doing? There are many ways you can support @keyframers so we can keep live coding awesome animations!

* Like & Subscribe on YouTube https://youtube.com/keyframers
* Spread the word! A Tweet about @keyframers is worth a thousand chars.
* Follow & Subscribe on Twitch and join the live streams at http://twitch.tv/keyframers 
* Support us on Patreon at https://patreon.com/keyframers !

Topics covered:

* Checkbox toggles
* CSS Variables
* background-clip: text