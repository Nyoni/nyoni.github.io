// initialize 

index = 0;
var i;

// call a function 
slideShow(index);

// plusSlide function 
function plusSlide() {
    slideShow(index = index + 1);
}

//minusSlide function
function minusSlide() {
    slideShow(index = index - 1);
}

//for the radio button clickable 
function currentSlide(n) {
    slideShow(index = n);
}


// function run here 

function slideShow(n) {

    var slide = document.getElementsByClassName("slider");
    // linkable to the next and back arrow button to the rdio button
    var dots = document.getElementsByClassName("dot");

    // console.log(slide);


    // condtion for plusSlide function 
    if (n > slide.length - 1) {
        index = 0;
    }

    //condition for minusSlide function
    if (n < 0) {
        index = slide.length - 1;
    }
    //run a for loop to overflow an image hidden.only 1 image show
    for (i = 0; i < slide.length; i++) {
        slide[i].style.display = "none";
    }

    // for the radio button

    for (i = 0; i < slide.length; i++) {
        dots[i].className = dots[i].className.replace("active");
    }


    // only one image show 
    slide[index].style.display = "block";
    // image show along with arrow button and radio button
    dots[index].className += " active";
}