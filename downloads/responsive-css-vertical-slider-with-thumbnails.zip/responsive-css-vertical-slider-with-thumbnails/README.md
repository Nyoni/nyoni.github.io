# Responsive CSS vertical slider with thumbnails

A Pen created on CodePen.io. Original URL: [https://codepen.io/huijing/pen/GvNLJm](https://codepen.io/huijing/pen/GvNLJm).

An experiment to create a completely responsive vertical slider with thumbnails using only CSS, and retaining the aspect ratio of the images.