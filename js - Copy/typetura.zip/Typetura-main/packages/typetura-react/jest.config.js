// jest.config.js
module.exports = {
  verbose: true,
  transformIgnorePatterns: ['[/\\\\]node_modules[/\\\\](?!typetura).+\\.(js|jsx)$'],
};
