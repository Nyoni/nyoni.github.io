import { typeturaInit } from './index';

window.typetura = window.typetura || {
  selectors: ['.typetura'],
  base: 20,
  scale: 1,
};

typeturaInit(window.typetura);
