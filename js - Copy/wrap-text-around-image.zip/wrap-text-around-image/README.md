# Wrap Text around Image

A Pen created on CodePen.io. Original URL: [https://codepen.io/demiton/pen/GRgdbYP](https://codepen.io/demiton/pen/GRgdbYP).

Simple Wrap Text around image or div with shape-outside property