# Slick Slider with auto play YouTube, Vimeo and HTML5 video

A Pen created on CodePen.io. Original URL: [https://codepen.io/digistate/pen/MvapbE](https://codepen.io/digistate/pen/MvapbE).

This sample is the tips for slick slider including YouTube, Vimeo and HTML5 video  player.
Each video plays automatically when the video slide has shown. And the slider fits the browser width.