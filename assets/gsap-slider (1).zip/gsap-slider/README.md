# GSAP slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/gvrban/pen/qjbpaa](https://codepen.io/gvrban/pen/qjbpaa).

Simple GSAP slider with some subtle tween animations