# Responsive video background

A Pen created on CodePen.io. Original URL: [https://codepen.io/horvath-laszlo/pen/EKvQOx](https://codepen.io/horvath-laszlo/pen/EKvQOx).

Example code for a HTML5 video background from coverr.co.