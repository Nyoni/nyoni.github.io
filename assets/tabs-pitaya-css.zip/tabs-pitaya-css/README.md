# Tabs. Pitaya CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/flkt-crnpio/pen/WxROwy](https://codepen.io/flkt-crnpio/pen/WxROwy).

Make tabs without javascript. 

More documentation here (in spanish)
http://flkt.mx/pitaya/componentes.html#pestanias