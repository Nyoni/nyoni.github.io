stroll.bind( '.scroll-container' );
$(".machine-card").click(function(){
  console.log("You clicked it");
  $(this).toggleClass("selected");
})