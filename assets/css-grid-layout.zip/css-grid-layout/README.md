# CSS Grid Layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/lariosme/pen/VEXLqM](https://codepen.io/lariosme/pen/VEXLqM).

