# Fullscreen HTML5 Video Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/nidhinnidhi/pen/jWrqrN](https://codepen.io/nidhinnidhi/pen/jWrqrN).

Here is a full screen html5 Video Background with simple steps