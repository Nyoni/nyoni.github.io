# #12 - Blog Card: Transparent Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/daiquiri/pen/GWpPKP](https://codepen.io/daiquiri/pen/GWpPKP).

