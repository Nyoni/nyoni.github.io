# Anime.js + ScrollMagic Scroll Based Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/rexjbull/pen/RwRRezq](https://codepen.io/rexjbull/pen/RwRRezq).

A example of using ScrollMagic to trigger Anime.js animations. Some of the animations are set to play when triggered and some are set to progress as the user scrolls the page.