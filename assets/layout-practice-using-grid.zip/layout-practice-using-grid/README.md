# Layout practice, using grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/bartveneman/pen/PQMzxp](https://codepen.io/bartveneman/pen/PQMzxp).

CSS Grid layout exercise using this Dribbble shot: https://dribbble.com/shots/3104643-Fire-Ice-Website/attachments/655216