# Daily UI Movie  Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/georgemiro/pen/oxrrwp](https://codepen.io/georgemiro/pen/oxrrwp).

