// Inspiration taken from:

https://codepen.io/kathykato/pen/gdvjax