var imgs = [
  "https://unsplash.s3.amazonaws.com/batch%206/park-place.jpg",
  "https://unsplash.s3.amazonaws.com/batch%206/Bird-Profile-Wellington-New-Zealand.jpg",
  "https://unsplash.s3.amazonaws.com/batch%205/greece-2.jpg",
  "https://unsplash.s3.amazonaws.com/batch%202/06.jpg"
           ]

$(document).ready(function(){
  
  //console.log($.stellar());
  //$('#bg').stellar();
  
  //$.stellar();
  
  var img;
  
  for(var i=0; i<imgs.length; i++){
    img = new Image();
    img.className = 'bgItems';
    
    img.onload = function(){
      var str = "'"+this.src+"'";
      $("#bg").append('<div class="img" style="background-image:url('+str+');"></div>');
      
    };
    
    img.src = imgs[i];
    
  }
  
  // end of loading images //
  
$(window).bind('scroll',function(e){
    parallaxScroll();
});
  
});

 
function parallaxScroll(){
    var scrolled = $(window).scrollTop();
    $('#parallax-bg1').css('top',(0-(scrolled*.02))+'px');
    $('.blockItem').css('top',(0-(scrolled*.5))+'px');
    
}