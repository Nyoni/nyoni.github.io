# Flex Hover Slider | HTML + CSS + jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/CameronFitzwilliam/pen/rmeMGr](https://codepen.io/CameronFitzwilliam/pen/rmeMGr).

This was the result of a challenge. You can read the my blog post about flex box here:

https://codepen.io/CameronFitzwilliam/post/flex-direction

*  Update - 21/10/2017  *
- Now works on smaller devices
