# Responsive Movie Card - Dark Version

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoberny/pen/qxxOqj](https://codepen.io/simoberny/pen/qxxOqj).

