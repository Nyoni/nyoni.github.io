# Simple jquery parallax scroll effect (updated 12 April 2017)

A Pen created on CodePen.io. Original URL: [https://codepen.io/hendrysadrak/pen/mdxLGK](https://codepen.io/hendrysadrak/pen/mdxLGK).

Simple parallax scroll that can be implemented everywhere.

#reoptimized