# Beatiful Thumbnail Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/dickyal6/pen/rNeRepd](https://codepen.io/dickyal6/pen/rNeRepd).

