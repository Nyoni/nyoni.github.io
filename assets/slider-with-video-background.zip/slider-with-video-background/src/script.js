let customEasy = CustomEase.create("custom", "M0,0 C0.11,0.494 0.192,0.726 0.318,0.852 0.45,0.984 0.978,1 1,1");


let retangle = document.querySelector(".retangle");
let tl = new TimelineMax();
let controlers = document.querySelector(".controlers");

tl.from(retangle, 1.5, {scale:"0", ease: Power4.easeOut},)
  .to(controlers, 1.5, {opacity:"1", ease: Power4.easeOut},"")
  .call(playSlider);
  



function playSlider(){
    let image01 = document.querySelector(".photo01");
    let image02 = document.querySelector(".photo02");
    let image03 = document.querySelector(".photo03");
    let video = document.querySelector(".bgvideo");
    
  
    let worktitle01 = document.querySelector("#worktitle01");
    let worktitle01_splited = new SplitText(worktitle01, {type:"lines"});
    let text01 = worktitle01_splited.lines;
  
    let worktitle02 = document.querySelector("#worktitle02");
    let worktitle02_splited = new SplitText(worktitle02, {type:"lines"});
    let text02 = worktitle02_splited.lines;
  
    let worktitle03 = document.querySelector("#worktitle03");
    let worktitle03_splited = new SplitText(worktitle03, {type:"lines"});
    let text03 = worktitle03_splited.lines;
  
  
    let tl = new TimelineMax({repeat:-1});
  
    let btNext = document.querySelector("#btnext");
    let btPrev = document.querySelector("#btprev");
  
    btPrev.onclick = function () { 
      let tlposition = tl.currentLabel();
      if(tlposition=="openImage1"){
        tl.seek("openImage2");
      }
      if(tlposition=="openImage2"){
        tl.seek("openImage3");
      }
      if(tlposition=="openImage3"){
        tl.seek("openImage1");
      }
    }
  
    btNext.onclick = function () { 
      
      
      let tlposition = tl.currentLabel();
      if(tlposition=="openImage1"){
        tl.seek("openImage3");
      }
      if(tlposition=="openImage3"){
        tl.seek("openImage2");
      }
      if(tlposition=="openImage2"){
        tl.seek("openImage1");
      }
      
      
    }
  
  
  
  
    // shows first item
    tl.set(image01, {opacity: 1},)
      .call(changeBGVideo, ["https://static.videezy.com/system/resources/previews/000/034/802/original/business6.mp4"])
      .set(retangle, {transformOrigin:"right bottom"},)
      .set(worktitle01, {display: "block"},)
      .to(retangle, 1, {scaleX:"0", ease: customEasy},'openImage1')
      .fromTo(video, 2, {opacity:"0"},{opacity:"0.05", ease: Power4.easeOut},"openImage1")
      .fromTo(image01, 4,{backgroundSize:"110% 110%"},{backgroundSize:"100% 100%", ease: Power4.easeOut},'openImage1')
      .staggerFrom (text01, 1, {scaleY:1.4,opacity:0, y:"35px", ease: Power4.easeOut}, 0.1, "-=3.5")
      
      .set(retangle, {transformOrigin:"left bottom"})
      .to(retangle, 0.5, {scaleX:"1", ease: Power4.easeOut},"+=4" )
      .staggerTo (text01, 0.3, {opacity:0, y: "-50px",ease: Power4.easeOut}, 0.1,"-=1")
      .to(video, 2, {opacity:"0", ease: Power4.easeOut},"-=2")
    //shows second item
  
  
      .call(changeBGVideo,["https://static.videezy.com/system/resources/previews/000/012/722/original/ny_timelapse_1___7_5s___2k_res.mp4"])
      .set(image01, {display: "none"},)
      .set(image02, {display: "block"},)
      .set(retangle, {transformOrigin:"right bottom"},)
      .set(worktitle01, {display: "none"},)
      .set(worktitle02, {display: "block"},)
      .to(retangle, 1, {scaleX:"0", ease: Power4.easeOut},'openImage2')
      .fromTo(video, 2, {opacity:"0"},{opacity:"0.05", ease: Power4.easeOut},"openImage2")
      .fromTo(image02, 4,{backgroundSize:"110% 110%"},{backgroundSize:"100% 100%", ease: Power4.easeOut},'openImage2')
      
      .staggerFrom (text02, 1, {scaleY:1.4,opacity:0, y:"35px", ease: Power4.easeOut}, 0.1, "-=3.5")
      
      .set(retangle, {transformOrigin:"left bottom"},)
      .to(retangle, 1, {scaleX:"1", ease: Power4.easeOut}, "+=4")
      .staggerTo (text02, 0.3, {opacity:0, y: "-50px",ease: Power4.easeOut}, 0.1,"-=1")
      .to(video, 2, {opacity:"0", ease: Power4.easeOut},"-=1")
  
    //shows third item
      .call(changeBGVideo,["https://static.videezy.com/system/resources/previews/000/036/534/original/DSCF3989-264.mp4"])
      .set(image02, {display: "none"},)
      .set(image03, {display: "block"},)
      .set(retangle, {transformOrigin:"right bottom"},)
      .set(worktitle02, {display: "none"},)
      .set(worktitle03, {display: "block"},)
      .to(retangle, 1, {scaleX:"0", ease: Power4.easeOut},'openImage3')
      .fromTo(video, 2, {opacity:"0"},{opacity:"0.05", ease: Power4.easeOut},"openImage3")
      .fromTo(image03, 4,{backgroundSize:"110% 110%"},{backgroundSize:"100% 100%", ease: Power4.easeOut},'openImage3')
      .staggerFrom (text03, 1, {scaleY:1.4,opacity:0, y:"35px", ease: Power4.easeOut}, 0.1,  "-=3.5")
      
      .set(retangle, {transformOrigin:"left bottom"},)
      .to(retangle, 1, {scaleX:"1", ease: Power4.easeOut},"+=4")
      .staggerTo (text03, 0.3, {opacity:0, y: "-50px",ease: Power4.easeOut}, 0.1,"-=1")
      .to(video, 2, {opacity:"0", ease: Power4.easeOut},"-=1");

}


function changeBGVideo(url){
  let BGvideo = document.querySelector('.bgvideo');
  BGvideo.src = url;
  video.play();
}



