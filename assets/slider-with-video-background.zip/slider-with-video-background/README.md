# Slider with video background

A Pen created on CodePen.io. Original URL: [https://codepen.io/leandroscosta/pen/KOZrgz](https://codepen.io/leandroscosta/pen/KOZrgz).

