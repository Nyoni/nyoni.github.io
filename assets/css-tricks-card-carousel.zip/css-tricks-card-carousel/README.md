# CSS-Tricks Card Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/william-goldsworthy/pen/JzVajj](https://codepen.io/william-goldsworthy/pen/JzVajj).

