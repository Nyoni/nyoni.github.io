# Video Background Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/1wdtv/pen/jbjZeb](https://codepen.io/1wdtv/pen/jbjZeb).

This flexible slider uses the very popular "swiper" responsive slider and provides a turnkey way for you to create an instant slideshow with your choice of video backgrounds!

Use with free videos from https://pixabay.com and you'll be up and running in no time!