# Responsive movie card

A Pen created on CodePen.io. Original URL: [https://codepen.io/ryanparag/pen/oWrLPr](https://codepen.io/ryanparag/pen/oWrLPr).

Responsive movie card