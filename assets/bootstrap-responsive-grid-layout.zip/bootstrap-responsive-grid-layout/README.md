# Bootstrap responsive grid layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/badiali/pen/MWwEWva](https://codepen.io/badiali/pen/MWwEWva).

Bootstrap responsive grid layout. Transition on hover effect. Background images cover size.