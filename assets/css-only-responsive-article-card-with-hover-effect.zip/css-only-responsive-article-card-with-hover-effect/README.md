# CSS only responsive article card with hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/cycosta/pen/vYLJxwq](https://codepen.io/cycosta/pen/vYLJxwq).

